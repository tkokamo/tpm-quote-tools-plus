/*
 * Load a key.
 * Copyright (C) 2010 The MITRE Corporation
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the BSD License as published by the
 * University of California.
 */

#if defined HAVE_CONFIG_H
#include "config.h"
#endif
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <tss/tspi.h>
#include "tpm_quote.h"

int tpm_loadkey(BYTE *blob, TSS_UUID uuid)
{
  UINT32 blobLen = strlen(blob);

  /* Create context */
  TSS_HCONTEXT hContext;	/* Context handle */
  TSS_RESULT rc = Tspi_Context_Create(&hContext);
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "creating context");

  rc = Tspi_Context_Connect(hContext, NULL);
  if (rc != TSS_SUCCESS)
    return tidy(hContext, tss_err(rc, "connecting"));

  if (loadkey(hContext, blob, blobLen, uuid))
    return tidy(hContext, 1);

  return tidy(hContext, 0);
}
