#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tss/tspi.h>
#include "tpm_quote.h"

TSS_RESULT tpm_getrandom(UINT32 size, BYTE *out){

	TSS_HCONTEXT hContext;
	int rc = Tspi_Context_Create(&hContext);
	if(rc != TSS_SUCCESS){
		return tss_err(rc, "creating context");
	}

	rc = Tspi_Context_Connect(hContext, NULL);
	if (rc != TSS_SUCCESS)
    		return tidy(hContext, tss_err(rc, "connecting"));

  	/* Get TPM handle */
  	TSS_HTPM hTPM;                /* TPM handle */
  	rc = Tspi_Context_GetTpmObject(hContext, &hTPM);
  	if (rc != TSS_SUCCESS)
    	return tidy(hContext, tss_err(rc, "getting TPM object"));

  	BYTE *nonce;

	rc = Tspi_TPM_GetRandom(hTPM, size, &nonce);
	if(rc != TSS_SUCCESS)
		return tidy(hContext, tss_err(rc, "generating a ramdom"));

	int i;	
	for(i = 0; i < size; i++){
		out[i] = nonce[i];	
	//printf("%02x",nonce[i]);
	} 	
//	memcpy(out, nonce, size);


	return tidy (hContext, TSS_SUCCESS);
};

int main(int argc, char **argv){

	if(argc < 2){
		fprintf(stderr, "Usage: %s size\n", argv[0]);
		return 1;
	}

	UINT32 size = atoi(argv[1]);
	BYTE *out;
	int i = 0;
	out = (BYTE *)malloc(sizeof(BYTE)*size);
	int rc = 0;
	if((rc = tpm_getrandom(size, out)) != TSS_SUCCESS){
		tss_err(rc, "getting random");
	}
        for(i = 0; i < size; i++){
		printf("%02x", out[i]);
	}
	putchar('\n');

	return 0;
}
