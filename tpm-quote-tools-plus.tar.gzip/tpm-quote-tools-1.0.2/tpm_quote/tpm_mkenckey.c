/*
 * Create Signing Key and Register
 *
 */
#include<stdio.h>
#include<tss/tspi.h>
#include"tpm_quote.h"

TSS_RESULT tpm_mksignkey(TSS_UUID uuid){

	TSS_HCONTEXT hContext;
	TSS_HTPM hTPM;
	TSS_FLAG initFlags;
	TSS_HKEY hKey;
	TSS_HKEY hSRK;
	TSS_RESULT rc;
	TSS_UUID SRK_UUID = TSS_UUID_SRK;
	UINT32 size;
	BYTE *pub;
	const char *pubkey = "pubkey_sign";
	TSS_HPOLICY srkUsagePolicy, keyUsagePolicy;
	BYTE well_known_secret[20] = TSS_WELL_KNOWN_SECRET;
	
	initFlags = TSS_KEY_TYPE_SIGNING | TSS_KEY_SIZE_2048 | TSS_KEY_NO_AUTHORIZATION | TSS_KEY_NOT_MIGRATABLE;
	/*Create Context*/
	if(rc = Tspi_Context_Create(&hContext)){
		return tidy(hContext, tss_err(rc, "context"));
	}
        /*Connext Context*/
	if(rc = Tspi_Context_Connect(hContext, NULL)){
		return tidy(hContext, tss_err(rc, "connect"));
	}	
	/*Create Object*/
	if(rc = Tspi_Context_CreateObject(hContext, TSS_OBJECT_TYPE_RSAKEY, initFlags, &hKey)){
		return tidy(hContext, tss_err(rc, "object"));
	}
	/*Get Policy Object: neccesary to load in TPM*/
	if(rc = Tspi_GetPolicyObject(hKey, TSS_POLICY_USAGE, &keyUsagePolicy)){
		return tidy(hContext, tss_err(rc, "policy object"));
	}
	/*Set Secret*/
	if(rc = Tspi_Policy_SetSecret(keyUsagePolicy, TSS_SECRET_MODE_SHA1, 20, well_known_secret)){
		return tidy(hContext, tss_err(rc, "set secret"));
	}
	/*Set the padding*/	
	if(rc = Tspi_SetAttribUint32(hKey, TSS_TSPATTRIB_KEY_INFO, TSS_TSPATTRIB_KEYINFO_SIGSCHEME, TSS_SS_RSASSAPKCS1V15_INFO)){
		return tidy(hContext, tss_err(rc, "setting"));
	}
	/*Load SRK*/
	if(rc = Tspi_Context_LoadKeyByUUID(hContext, TSS_PS_TYPE_SYSTEM, SRK_UUID, &hSRK)){
		return tidy(hContext, tss_err(rc, "loading SRK"));
	}
	/*Create Signing Key*/
	if(rc = Tspi_Key_CreateKey(hKey, hSRK, 0)){
		return tidy(hContext, tss_err(rc, "Creating KEY"));
	}
	/*register key*/
	if(rc = Tspi_Context_RegisterKey(hContext, hKey, TSS_PS_TYPE_SYSTEM, uuid, TSS_PS_TYPE_SYSTEM, SRK_UUID )){
		return tidy(hContext, tss_err(rc, "Registering Key"));
	}
	//Registered 
	//Output public key
	/*Load in TPM*/
	if(rc = Tspi_Key_LoadKey(hKey, hSRK)){
		return tidy(hContext, tss_err(rc, "Loading Key in TPM"));
	}
	if(rc = Tspi_Key_GetPubKey(hKey, &size, &pub)){
		return tidy(hContext, tss_err(rc, "Getting Pub Key"));
	}
	FILE *fout = fopen(pubkey, "wb");
	if(fout == NULL){
		fprintf(stderr, "cannot open file.");
		return 1;
	}
	if(0 >= fwrite(pub, size, sizeof(BYTE), fout)){
		fprintf(stderr, "fwrite error." );
		return 1;
	}	
	fclose(fout);

	if(rc == TSS_SUCCESS){
		tidy(hContext, rc);
	}
#if DEBUG
 
#endif	
	return TSS_SUCCESS;
}


int main(){

	TSS_HCONTEXT hContext;
  	int rc = Tspi_Context_Create(&hContext);
  	if (rc != TSS_SUCCESS)
    		return tss_err(rc, "creating context");
    
  	rc = Tspi_Context_Connect(hContext, NULL);
  	if (rc != TSS_SUCCESS)
    		return tidy(hContext, tss_err(rc, "connecting"));

  	/* Get TPM handle */
 	 TSS_HTPM hTPM;                /* TPM handle */
  		rc = Tspi_Context_GetTpmObject(hContext, &hTPM);
  	if (rc != TSS_SUCCESS) 
    	return tidy(hContext, tss_err(rc, "getting TPM object"));

  	TSS_UUID *uuid;
  	/* Generate a UUID for the key */
  	rc = Tspi_TPM_GetRandom(hTPM, sizeof(TSS_UUID), (BYTE **)&uuid);
  	if (rc != TSS_SUCCESS)
    		return tidy(hContext, tss_err(rc, "generating a key UUID"));

  	// Put in the variant and version bits
  	uuid->usTimeHigh &= 0x0FFF;
  	uuid->usTimeHigh |= (4 << 12);
	uuid->bClockSeqHigh &= 0x3F;
  	uuid->bClockSeqHigh |= 0x80;

	tpm_mksignkey(*uuid);

}

