int tpm_quote(TSS_UUID uuid, BYTE *blob, UINT32 blobLen, BYTE *nonce, char **pcrs_p, UINT32 npcrs);
int tpm_loadkey(BYTE *blob, UINT32 blobLen, TSS_UUID uuid);
int tpm_mkaik();
int tpm_mkuuid();

