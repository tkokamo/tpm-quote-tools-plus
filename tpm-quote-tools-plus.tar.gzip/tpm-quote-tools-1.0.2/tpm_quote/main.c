#include <stdio.h>
#include <stdlib.h>
#include <tss/tspi.h>
#include "tpm_quote.h"
#include "quote_plus.h"

int main(){
 
  const char *uuidname = "uuid";
  const char *blobname = "blob";
  const char *pubkeyname = "pubkey";

  /*file open*/  
  FILE * uuid_d;
  FILE * blob_d;
  FILE * pubkey_d;

  fprintf(stderr, "TEST START\n");

  /*mkuuid check*/  
  tpm_mkuuid();
  fprintf(stderr, "tpm_mkuuid SUCCESS\n");
  /*mkaik check*/
  tpm_mkaik();  
  fprintf(stderr, "tpm_mkaik SUCCESS\n");

  /*loadkey check*/
  uuid_d = fopen(uuidname, "rb");
  if (!uuid_d) {
    fprintf(stderr, "Cannot open %s\n", uuidname);
    return 1;
  }

  TSS_UUID uuid;
  if (sizeof uuid != fread((void *)&uuid, 1, sizeof uuid, uuid_d)) {
    fprintf(stderr, "Expecting a uuid of %zd bytes in %s\n",
            sizeof uuid, uuidname);
    return 1;
  }
  fclose(uuid_d);
  
  blob_d = fopen(blobname, "rb");
  if(!blob_d) {
    fprintf(stderr, "Cannot open %s\n", blobname);
    return 1;
  }

  BYTE blob[2048];
  UINT32 blob_len;
  if ((blob_len = fread((void *)&blob, 1, 2048, blob_d)) == 0){
    fprintf(stderr, "Cannot read %s\n", blobname);
    return 1;
  }
  fclose(blob_d);
  blob[blob_len] = '\0';
  tpm_loadkey((BYTE *)blob, blob_len, uuid);
  fprintf(stderr, "tpm_loadkey SUCCESS\n" );

  /*getquote check*/
  /*get NONCE*/
  /* Create context */
  TSS_HCONTEXT hContext;
  int rc = Tspi_Context_Create(&hContext);
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "creating context");

  rc = Tspi_Context_Connect(hContext, NULL);
  if (rc != TSS_SUCCESS)
    return tidy(hContext, tss_err(rc, "connecting"));

  /* Get TPM handle */
  TSS_HTPM hTPM;                /* TPM handle */
  rc = Tspi_Context_GetTpmObject(hContext, &hTPM);
  if (rc != TSS_SUCCESS)
    return tidy(hContext, tss_err(rc, "getting TPM object"));

  BYTE **nonce = (BYTE **)malloc(sizeof(BYTE *));
  *nonce = "00000000000000000000";
  /* Generate a UUID for the key */
 // rc = Tspi_TPM_GetRandom(hTPM, 20, nonce);
 // if (rc != TSS_SUCCESS)
 //   return tidy(hContext, tss_err(rc, "generating a nonce"));
  char *p = "1";
  char **pcr = (char **)malloc(sizeof(char *));
  *pcr = p;

  fprintf(stderr, "generate a nonce %s SUCCESS.\n", *nonce);
  tpm_quote(uuid, blob, blob_len, *nonce, (char **)pcr, 1);

  //free(p);
 
  fprintf(stderr, "tpm_getquote SUCCESS.\n");
}
